import React, { useState } from 'react';
import { 
  Mic, 
  BarChart3, 
  BookOpen, 
  Users, 
  Settings, 
  Zap,
  Play,
  MessageSquare,
  Bot
} from 'lucide-react';
import Dashboard from './components/Dashboard';
import LiveCall from './components/LiveCall';
import ObjectionLibrary from './components/ObjectionLibrary';
import CallPlanner from './components/CallPlanner';
import Analytics from './components/Analytics';
import TeamManagement from './components/TeamManagement';
import SettingsPage from './components/SettingsPage';
import AutonomousMode from './components/AutonomousMode';

type View = 'dashboard' | 'live-call' | 'objections' | 'planner' | 'analytics' | 'team' | 'settings' | 'autonomous';

function App() {
  const [currentView, setCurrentView] = useState<View>('dashboard');
  const [isCallActive, setIsCallActive] = useState(false);

  const navigation = [
    { id: 'dashboard', name: 'Dashboard', icon: BarChart3, view: 'dashboard' },
    { id: 'live-call', name: 'Live Call', icon: Mic, view: 'live-call', highlight: true },
    { id: 'autonomous', name: 'Autonomous', icon: Bot, view: 'autonomous' },
    { id: 'objections', name: 'Objections', icon: MessageSquare, view: 'objections' },
    { id: 'planner', name: 'Call Planner', icon: BookOpen, view: 'planner' },
    { id: 'analytics', name: 'Analytics', icon: BarChart3, view: 'analytics' },
    { id: 'team', name: 'Team', icon: Users, view: 'team' },
    { id: 'settings', name: 'Settings', icon: Settings, view: 'settings' }
  ];

  const handleStartCall = () => {
    setIsCallActive(true);
    setCurrentView('live-call');
  };

  const renderView = () => {
    switch (currentView) {
      case 'dashboard':
        return <Dashboard onStartCall={handleStartCall} />;
      case 'live-call':
        return <LiveCall isActive={isCallActive} onEndCall={() => setIsCallActive(false)} />;
      case 'autonomous':
        return <AutonomousMode />;
      case 'objections':
        return <ObjectionLibrary />;
      case 'planner':
        return <CallPlanner />;
      case 'analytics':
        return <Analytics />;
      case 'team':
        return <TeamManagement />;
      case 'settings':
        return <SettingsPage />;
      default:
        return <Dashboard onStartCall={handleStartCall} />;
    }
  };

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-white">
      {/* Header */}
      <header className="border-b border-gray-800 bg-[#0a0a0a]/95 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-screen-2xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            {/* Logo */}
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-pink-600 rounded-lg flex items-center justify-center">
                <Zap className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold bg-gradient-to-r from-purple-400 to-pink-600 bg-clip-text text-transparent">
                  CLOSER AI
                </h1>
                <p className="text-xs text-gray-400">Your AI Sales Co-Pilot</p>
              </div>
            </div>

            {/* Quick Start Call */}
            <button
              onClick={handleStartCall}
              className={`flex items-center gap-2 px-6 py-3 rounded-lg font-medium transition-all ${
                isCallActive
                  ? 'bg-red-500 hover:bg-red-600 animate-pulse'
                  : 'bg-gradient-to-r from-purple-500 to-pink-600 hover:from-purple-600 hover:to-pink-700'
              }`}
            >
              {isCallActive ? (
                <>
                  <div className="w-2 h-2 bg-white rounded-full animate-pulse" />
                  <span>Call Active</span>
                </>
              ) : (
                <>
                  <Play className="w-4 h-4" />
                  <span>Start Call</span>
                </>
              )}
            </button>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar */}
        <aside className="w-64 border-r border-gray-800 min-h-[calc(100vh-73px)] bg-[#0a0a0a] sticky top-[73px]">
          <nav className="p-4 space-y-1">
            {navigation.map((item) => {
              const Icon = item.icon;
              const isActive = currentView === item.view;
              return (
                <button
                  key={item.id}
                  onClick={() => setCurrentView(item.view as View)}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-all ${
                    isActive
                      ? 'bg-gradient-to-r from-purple-500/20 to-pink-600/20 text-white border border-purple-500/30'
                      : 'text-gray-400 hover:text-white hover:bg-gray-800/50'
                  } ${item.highlight && !isActive ? 'border border-purple-500/20' : ''}`}
                >
                  <Icon className="w-5 h-5" />
                  <span className="font-medium">{item.name}</span>
                  {item.highlight && !isActive && (
                    <span className="ml-auto px-2 py-0.5 bg-purple-500/20 text-purple-400 text-xs rounded-full">
                      Live
                    </span>
                  )}
                </button>
              );
            })}
          </nav>

          {/* Upgrade Card */}
          <div className="m-4 p-4 bg-gradient-to-br from-purple-900/20 to-pink-900/20 border border-purple-500/20 rounded-lg">
            <div className="flex items-center gap-2 mb-2">
              <Zap className="w-4 h-4 text-purple-400" />
              <h3 className="font-semibold text-sm">Upgrade to Pro</h3>
            </div>
            <p className="text-xs text-gray-400 mb-3">
              Unlock autonomous mode, unlimited calls, and advanced AI features.
            </p>
            <button className="w-full px-3 py-2 bg-gradient-to-r from-purple-500 to-pink-600 hover:from-purple-600 hover:to-pink-700 rounded-lg text-sm font-medium transition-all">
              Upgrade Now
            </button>
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1 overflow-auto">
          {renderView()}
        </main>
      </div>
    </div>
  );
}

export default App;
