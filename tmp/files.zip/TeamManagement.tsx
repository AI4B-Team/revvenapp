import React from 'react';
import { Users, UserPlus, Trophy, TrendingUp } from 'lucide-react';

const TeamManagement: React.FC = () => {
  const teamMembers = [
    { name: 'John Smith', calls: 45, closeRate: 72, aiUsage: 95, avatar: 'JS' },
    { name: 'Sarah Williams', calls: 38, closeRate: 68, aiUsage: 88, avatar: 'SW' },
    { name: 'Mike Johnson', calls: 41, closeRate: 65, aiUsage: 92, avatar: 'MJ' }
  ];

  return (
    <div className="p-8 max-w-screen-2xl mx-auto">
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-3xl font-bold">Team Management</h1>
        <button className="flex items-center gap-2 px-4 py-2 bg-purple-500 hover:bg-purple-600 rounded-lg">
          <UserPlus className="w-4 h-4" />
          Invite Member
        </button>
      </div>

      <div className="space-y-4">
        {teamMembers.map((member, index) => (
          <div key={index} className="bg-[#1e1e1e] border border-gray-800 rounded-xl p-6 flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-pink-600 rounded-full flex items-center justify-center font-bold">
                {member.avatar}
              </div>
              <div>
                <h3 className="font-bold">{member.name}</h3>
                <p className="text-sm text-gray-400">{member.calls} calls this week</p>
              </div>
            </div>

            <div className="flex gap-8">
              <div className="text-center">
                <div className="text-2xl font-bold text-emerald-400">{member.closeRate}%</div>
                <div className="text-xs text-gray-400">Close Rate</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-purple-400">{member.aiUsage}%</div>
                <div className="text-xs text-gray-400">AI Usage</div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default TeamManagement;
