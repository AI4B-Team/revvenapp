import React from 'react';
import { TrendingUp, TrendingDown, Eye, MousePointerClick, Phone, Clock, Target, Award } from 'lucide-react';

const Analytics: React.FC = () => {
  const metrics = [
    { label: 'Total Calls', value: '1,247', change: '+23%', trend: 'up', icon: Phone, color: 'purple' },
    { label: 'Calls with AI', value: '892', change: '+45%', trend: 'up', icon: Target, color: 'emerald' },
    { label: 'Avg Duration', value: '18:43', change: '-3:12', trend: 'down', icon: Clock, color: 'blue' },
    { label: 'Close Rate', value: '67%', change: '+12%', trend: 'up', icon: Award, color: 'orange' }
  ];

  return (
    <div className="p-8 max-w-screen-2xl mx-auto">
      <h1 className="text-3xl font-bold mb-8">Analytics Dashboard</h1>
      <div className="grid grid-cols-4 gap-6">
        {metrics.map((metric, index) => {
          const Icon = metric.icon;
          const TrendIcon = metric.trend === 'up' ? TrendingUp : TrendingDown;
          return (
            <div key={index} className="bg-[#1e1e1e] border border-gray-800 rounded-xl p-6">
              <div className={`w-12 h-12 bg-${metric.color}-500/10 rounded-lg flex items-center justify-center mb-4`}>
                <Icon className={`w-6 h-6 text-${metric.color}-400`} />
              </div>
              <div className="text-3xl font-bold mb-1">{metric.value}</div>
              <div className="text-sm text-gray-400 mb-2">{metric.label}</div>
              <div className={`flex items-center gap-1 text-sm font-medium ${metric.trend === 'up' ? 'text-emerald-400' : 'text-red-400'}`}>
                <TrendIcon className="w-4 h-4" />
                {metric.change}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default Analytics;
