import React from 'react';
import {
  Phone,
  TrendingUp,
  Target,
  Clock,
  Zap,
  Award,
  BarChart3,
  Users,
  Play
} from 'lucide-react';

interface DashboardProps {
  onStartCall: () => void;
}

const Dashboard: React.FC<DashboardProps> = ({ onStartCall }) => {
  const stats = [
    {
      label: 'Total Calls',
      value: '247',
      change: '+23% vs last week',
      icon: Phone,
      color: 'purple'
    },
    {
      label: 'Close Rate',
      value: '67%',
      change: '+12% with AI assist',
      icon: Target,
      color: 'emerald'
    },
    {
      label: 'Avg Call Duration',
      value: '18:43',
      change: '-3 min with AI',
      icon: Clock,
      color: 'blue'
    },
    {
      label: 'Revenue Impact',
      value: '$284K',
      change: '+$67K this month',
      icon: TrendingUp,
      color: 'orange'
    }
  ];

  const recentCalls = [
    {
      id: '1',
      prospect: 'Sarah Johnson',
      company: 'Acme Corp',
      duration: '23:45',
      outcome: 'closed',
      sentiment: 85,
      date: '2 hours ago'
    },
    {
      id: '2',
      prospect: 'Michael Chen',
      company: 'TechStart Inc',
      duration: '15:30',
      outcome: 'follow-up',
      sentiment: 72,
      date: '4 hours ago'
    },
    {
      id: '3',
      prospect: 'Emily Rodriguez',
      company: 'Growth Labs',
      duration: '19:15',
      outcome: 'closed',
      sentiment: 91,
      date: 'Yesterday'
    }
  ];

  const topPerformers = [
    { name: 'John Smith', calls: 45, closeRate: 72, revenue: '$124K' },
    { name: 'Sarah Williams', calls: 38, closeRate: 68, revenue: '$98K' },
    { name: 'Mike Johnson', calls: 41, closeRate: 65, revenue: '$87K' }
  ];

  return (
    <div className="p-8 max-w-screen-2xl mx-auto">
      {/* Welcome Section */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Welcome back, Alex! 👋</h1>
        <p className="text-gray-400">Your AI co-pilot is ready to help you close more deals</p>
      </div>

      {/* Quick Start Card */}
      <div className="mb-8 p-6 bg-gradient-to-r from-purple-900/30 to-pink-900/30 border border-purple-500/30 rounded-xl">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-pink-600 rounded-full flex items-center justify-center">
              <Zap className="w-8 h-8" />
            </div>
            <div>
              <h3 className="text-2xl font-bold mb-1">Ready to crush your quota?</h3>
              <p className="text-gray-400">Start a call and let AI guide you to the close</p>
            </div>
          </div>
          <button
            onClick={onStartCall}
            className="flex items-center gap-2 px-8 py-4 bg-gradient-to-r from-purple-500 to-pink-600 hover:from-purple-600 hover:to-pink-700 rounded-lg font-bold text-lg transition-all transform hover:scale-105"
          >
            <Play className="w-6 h-6" />
            Start New Call
          </button>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <div
              key={index}
              className="bg-[#1e1e1e] border border-gray-800 rounded-xl p-6 hover:border-purple-500/30 transition-all"
            >
              <div className="flex items-center justify-between mb-4">
                <div className={`w-12 h-12 bg-${stat.color}-500/10 rounded-lg flex items-center justify-center`}>
                  <Icon className={`w-6 h-6 text-${stat.color}-400`} />
                </div>
                <span className="text-xs text-emerald-400 font-medium">{stat.change}</span>
              </div>
              <div className="text-3xl font-bold mb-1">{stat.value}</div>
              <div className="text-sm text-gray-400">{stat.label}</div>
            </div>
          );
        })}
      </div>

      {/* Recent Calls & Top Performers */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        {/* Recent Calls */}
        <div className="lg:col-span-2 bg-[#1e1e1e] border border-gray-800 rounded-xl p-6">
          <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
            <Phone className="w-5 h-5 text-purple-400" />
            Recent Calls
          </h3>
          <div className="space-y-3">
            {recentCalls.map((call) => (
              <div
                key={call.id}
                className="flex items-center justify-between p-4 bg-gray-900 rounded-lg hover:bg-gray-800 transition-colors cursor-pointer"
              >
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-pink-600 rounded-full flex items-center justify-center">
                    <span className="text-sm font-bold">{call.prospect[0]}</span>
                  </div>
                  <div>
                    <div className="font-semibold">{call.prospect}</div>
                    <div className="text-sm text-gray-400">{call.company} • {call.date}</div>
                  </div>
                </div>

                <div className="flex items-center gap-4">
                  <div className="text-right">
                    <div className="text-sm font-medium">{call.duration}</div>
                    <div className="text-xs text-gray-400">Duration</div>
                  </div>
                  
                  <div className="text-right">
                    <div className="text-sm font-medium">{call.sentiment}%</div>
                    <div className="text-xs text-gray-400">Sentiment</div>
                  </div>

                  <span
                    className={`px-3 py-1 rounded-full text-xs font-medium ${
                      call.outcome === 'closed'
                        ? 'bg-emerald-500/20 text-emerald-400'
                        : 'bg-yellow-500/20 text-yellow-400'
                    }`}
                  >
                    {call.outcome === 'closed' ? '✓ Closed' : '→ Follow-up'}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Top Performers */}
        <div className="bg-[#1e1e1e] border border-gray-800 rounded-xl p-6">
          <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
            <Award className="w-5 h-5 text-yellow-400" />
            Top Performers
          </h3>
          <div className="space-y-3">
            {topPerformers.map((performer, index) => (
              <div
                key={index}
                className="flex items-center gap-3 p-3 bg-gray-900 rounded-lg"
              >
                <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                  index === 0
                    ? 'bg-yellow-500/20 text-yellow-400'
                    : index === 1
                    ? 'bg-gray-500/20 text-gray-400'
                    : 'bg-orange-500/20 text-orange-400'
                }`}>
                  <span className="font-bold">#{index + 1}</span>
                </div>
                <div className="flex-1">
                  <div className="font-medium text-sm">{performer.name}</div>
                  <div className="text-xs text-gray-400">
                    {performer.calls} calls • {performer.closeRate}% close rate
                  </div>
                </div>
                <div className="text-sm font-bold text-emerald-400">{performer.revenue}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* AI Insights */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="p-6 bg-gradient-to-br from-purple-900/20 to-purple-800/20 border border-purple-500/20 rounded-xl">
          <div className="flex items-center gap-3 mb-4">
            <BarChart3 className="w-6 h-6 text-purple-400" />
            <h3 className="font-bold text-lg">AI Performance Boost</h3>
          </div>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-400">Objection Handling</span>
              <span className="text-emerald-400 font-semibold">+89%</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-400">Rapport Building</span>
              <span className="text-emerald-400 font-semibold">+67%</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-400">Close Success Rate</span>
              <span className="text-emerald-400 font-semibold">+45%</span>
            </div>
          </div>
        </div>

        <div className="p-6 bg-gradient-to-br from-emerald-900/20 to-emerald-800/20 border border-emerald-500/20 rounded-xl">
          <div className="flex items-center gap-3 mb-4">
            <Users className="w-6 h-6 text-emerald-400" />
            <h3 className="font-bold text-lg">Team Impact</h3>
          </div>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-400">New Rep Ramp Time</span>
              <span className="text-emerald-400 font-semibold">-67%</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-400">Average Deal Size</span>
              <span className="text-emerald-400 font-semibold">+$12K</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-400">Team Quota Attainment</span>
              <span className="text-emerald-400 font-semibold">142%</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
