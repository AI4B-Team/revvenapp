import React from 'react';
import { Settings, Upload, Mic, Bot, Zap } from 'lucide-react';

const SettingsPage: React.FC = () => {
  return (
    <div className="p-8 max-w-4xl mx-auto">
      <h1 className="text-3xl font-bold mb-8">Settings</h1>

      <div className="space-y-6">
        <div className="bg-[#1e1e1e] border border-gray-800 rounded-xl p-6">
          <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
            <Upload className="w-5 h-5 text-purple-400" />
            Custom Scripts & Frameworks
          </h3>
          <p className="text-sm text-gray-400 mb-4">
            Upload your sales scripts, playbooks, and methodologies to train AI on your approach
          </p>
          <button className="px-4 py-2 bg-purple-500 hover:bg-purple-600 rounded-lg">
            Upload Files
          </button>
        </div>

        <div className="bg-[#1e1e1e] border border-gray-800 rounded-xl p-6">
          <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
            <Mic className="w-5 h-5 text-purple-400" />
            Voice Settings
          </h3>
          <p className="text-sm text-gray-400 mb-4">
            Customize AI voice tone, speed, and personality
          </p>
          <button className="px-4 py-2 bg-purple-500 hover:bg-purple-600 rounded-lg">
            Configure Voice
          </button>
        </div>

        <div className="bg-[#1e1e1e] border border-gray-800 rounded-xl p-6">
          <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
            <Bot className="w-5 h-5 text-purple-400" />
            AI Behavior
          </h3>
          <p className="text-sm text-gray-400 mb-4">
            Adjust how aggressive, consultative, or direct the AI should be
          </p>
          <button className="px-4 py-2 bg-purple-500 hover:bg-purple-600 rounded-lg">
            Tune AI
          </button>
        </div>
      </div>
    </div>
  );
};

export default SettingsPage;
