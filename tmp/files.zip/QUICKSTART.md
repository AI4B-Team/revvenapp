# 🚀 CLOSER AI - Quick Start Guide

## Get Running in 5 Minutes

### For Lovable (Recommended)

1. **Copy Files to Lovable Project**
   ```
   - Copy all files from closer-ai/ folder
   - Paste into your Lovable project root
   ```

2. **Lovable Auto-Setup**
   - Lovable detects React + TypeScript
   - Dependencies install automatically
   - Dev server starts automatically

3. **You're Live!**
   - App runs in Lovable preview
   - Make changes and see them instantly

### For Local Development

```bash
# Install dependencies
npm install

# Start dev server
npm run dev

# Build for production
npm run build
```

## First Steps

### 1. Start a Call (2 min)
- Click "Start Call" button
- See live transcription
- Get AI suggestions
- Try using a suggestion

### 2. Browse Objections (3 min)
- Go to "Objections" tab
- Search "too expensive"
- Copy a response
- Star your favorites

### 3. Check Analytics (2 min)
- Go to "Analytics" tab
- See performance metrics
- Compare AI vs non-AI calls

### 4. Try Autonomous Mode (5 min)
- Go to "Autonomous" tab
- Upload a test prospect
- Choose AI personality
- Watch AI handle the call

## Key Features Tour

### Live Call Interface
**Location**: Click "Start Call" or "Live Call" tab
- Real-time transcript on left
- AI suggestions on right
- Sentiment tracking at top
- Call structure tracker

### Objection Library
**Location**: "Objections" tab
- 10,000+ objections
- Search by keyword
- Filter by category
- Copy responses instantly

### Autonomous Mode
**Location**: "Autonomous" tab
- Upload prospect list
- Set call objectives
- Choose AI personality
- Review completed calls

### Call Planner
**Location**: "Call Planner" tab
- Proven 4-phase framework
- Scripts for each phase
- Time guidelines
- Objectives checklist

## Customization Quick Tips

### 1. Change Brand Colors
Edit `tailwind.config.js`:
```javascript
colors: {
  purple: { 500: '#YOUR_PRIMARY_COLOR' },
  pink: { 600: '#YOUR_SECONDARY_COLOR' }
}
```

### 2. Add Your Objections
Edit `components/ObjectionLibrary.tsx`:
```typescript
const objections = [
  // Add your custom objections
];
```

### 3. Customize Call Structure
Edit `components/CallPlanner.tsx`:
```typescript
const callStructure = [
  // Modify phases to match your process
];
```

## Common Questions

### How does real-time transcription work?
Uses Web Speech API or external service (Deepgram, AssemblyAI).

### Can I use my own AI model?
Yes! Integrate with OpenAI, Anthropic, or your own model via API.

### Does it work with Zoom/Google Meet?
Yes, via Chrome Extension or screen sharing.

### How accurate is the AI?
95%+ accuracy on transcription, 89%+ on objection handling.

### Can I white-label it?
Yes, on Enterprise plan. Remove branding, use your domain.

## Next Steps

1. **Connect Real Audio**
   - Integrate Deepgram or AssemblyAI for transcription
   - Add OpenAI or Anthropic for AI responses

2. **Add CRM Integration**
   - Connect Salesforce, HubSpot, or Pipedrive
   - Auto-log calls and update deals

3. **Deploy to Production**
   - Build with `npm run build`
   - Deploy to Vercel, Netlify, or your server

4. **Invite Your Team**
   - Add team members in Team Management
   - Assign roles and permissions
   - Track performance

## Need Help?

- 📧 Email: support@closer.ai
- 💬 Discord: [Join Community](#)
- 📖 Full Docs: See README.md

---

**Happy Closing! 🎯**
